from collections import defaultdict

class LevelThree:

    def __init__(self):
        self.data = defaultdict(list)
        
    def addkey(self, protein, cdd):
    	self.data[protein].append(cdd)