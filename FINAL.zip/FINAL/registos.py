from collections import defaultdict
from gene import Gene
from protein import Protein

class Record:
    def __init__(self):
        self.genes = defaultdict(list)
        self.proteins = defaultdict(list)
        
#GENES
    def getNameFromID (self,id):
        return self.genes[id].gene_name
    
    def getLOCUSFromID(self,id):
        return self.genes[id].locus_tag

    def getECFromID (self,id):
        return self.genes[id].ecs

    def getSEQFromID (self,id):
        return self.genes[id].seq


#PROTEINAS

    def getNameFromPROTID (self,id):
        return self.proteins[id].prot_name

    def getECFromPROTID (self,id):
        return self.proteins[id].ecs
        
    def getAAFromPROTID (self,id):
        return self.proteins[id].aa