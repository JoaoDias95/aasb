class Gene:
    
    def __init__(self,tag,name,ecs,seq):
        self.locus_tag=tag
        self.gene_name=name
        self.ecs=ecs
        self.seq=seq


   
   # def getCDSFromID,4 : getPROTfromID, estruturas auxiliares