from levelOne import LevelOne
from levelTwo import LevelTwo 
from levelThree import LevelThree 
from registos import Record
from Bio import SeqIO


#GENE
def getCDSFromID (id):
    return LevelOne.getValues(id)

def getPROTfromID(id):
    vals= LevelOne.getValues(id)
    for i in range (0, len(vals)):
        results+= LevelTwo.getValues(vals[i])
    return results

def getALLIDfromSRUCT():
    presentGeneTb()

#PROTEIN
def getGENEfromPROTID(id):
    print ("FALTA")

def getCDSFromPROTID(id):
    print ("FALTA")

def getCDDfromPROTID (id):
    print("FALTA")

def getALLPROTIDfromSRUCT():
    print("FALTA")

#INTERFACE
def inputChange(levelone):
    print("Qual atividade pretende: \n 1 - Apresentacao da tabela com todos os Genomas \n 2 - Insercao de genoma (ID)")
    opt = int(raw_input(">"))
    options = {1:LevelOne.presentGeneTb,2:LevelOne.addkey}
    if (opt == 1):
        options[opt](levelone)
    elif(opt==2):
        try:
            print("Qual o Id que pertende adicionar:")
            data_Id = raw_input(">")
            vals = levelone.data.keys()
            if (data_Id in vals):
                print ("Valor ja presente na sua estrutura.")
                type = 2
            else:
                type =0
                levelone.isGene(data_Id)
        except Exception:
            print("INPUT INVALIDO : Id de Genoma inexistente")
            type = -1
        if (type != -1 and type != 2 ):
            #record = SeqIO.parse("aux.gb","genbank")
            #record.features = [f for f in record.features if f.type == "CDS"]
            #SeqIO.write(record, "only_cds.gbk", "genbank")
            #obter os cds e adicionalos ao dicionario, caso vazio fica empty
            levelone.addkey(data_Id,"EMPTY")
            #falta adicionar ao registo total a info e incializar a CDS especifica
            #genomes[data_Id] = Genome()
            print("Genoma adicionado com SUCESSO")
    else:
        print("Opcao errada!")






def main():
    levelone = LevelOne()
    leveltwo = LevelTwo()
    levethree = LevelThree()
    registos = Record()
    work=1
    print("Bem-Vindo!")
    while (work):
        print("O que pretende fazer? \n 1 - Operacoes sobre a Database \n 2 - Obter resultados \n X - Sair")
        option = raw_input(">")
        if (str(option) == "1"):
            inputChange(levelone)
        elif (str(option) == "2"):
            print ("Pretende atuar sobre que dados?\n 1 - Genes\n 2 - Proteins\n 3 - Coding DNA Sequence (CDS)\n Conserved Domain Database (CDD)\n")
            option = int(raw_input(">"))
            if (option == 1):
                print ("Funcionalidade pretendida: \n -------- GENE -------- \n 1 - Obter nome de um Gene\n 2 - Obter numero EC")
                print(" 3 - Obter todas as CDS de um Gene \n 4 - Obter todas as Proteinas codificadas por um Gene \n 5 - Analisar Sequencia")
                print("6 - Verificar todos os Genes na estrutura")
                options = {1:registos.getNameFromID,2:registos.getECFromID,3:getCDSFromID,4 : getPROTfromID,5 : registos.getSEQFromID,6 : getALLIDfromSRUCT}
            #options = {0:getFuncFromID,1:getSeqFromID,2 : getAAfromID,3 : getDomainFromID,4 : getIDfromSeq,5 : getTipoFromID,6 : getIDUniProt,7 : getLocusTag,8 : getGeneName, 9 : getProteinID}
            elif(option ==2):
                print(" -------- PROTEIN -------- \n 1 - Obter nome de uma Proteina \n 2 - Obter numero EC")
                print(" 3 - Obter Gene codificante \n 4 - Obter CDS especifico de Proteina \n 5 - Obter CDD especificas de Proteina")
                print(" 6 - Analisar Sequencia da AA \n 7 - Listar todas as Proteinas na estrutura")
                options = {1:registos.getNameFromPROTID,2:registos.getECFromPROTID,3: getGENEfromPROTID,4:getCDSFromPROTID,5 : getCDDfromPROTID,5 : registos.getAAFromPROTID,6 : getALLPROTIDfromSRUCT}
                num =int(raw_input(">"))
                print("Insira o Id")
                id = raw_input(">")
                options[num](id)
        elif(str(option) == "X" or str(option) == "x" ):
            print("Ate uma proxima")
            break
        else:
            print("Input Error - Selecione novamente uma opcao")
        
        

if __name__ == "__main__":
    main()