from levelOne import LevelOne 




def inputChange(levelone):
    print("Qual atividade pretende: \n 1 - Apresentacao da tabela com todos os Genomas \n 2 - Insercao de genoma (ID)")
    opt = int(raw_input(">"))
    options = {1:LevelOne.presentGeneTb,2:LevelOne.addkey}
    if (opt == 1):
        options[opt](levelone)
    elif(opt==2):
        try:
            print("Qual o Id que pertende adicionar:")
            data_Id = raw_input(">")
            vals = levelone.data.keys()
            if (data_Id in vals):
                print ("Valor ja presente na sua estrutura.")
                type = 2
            else:
                type =0
                levelone.isGene(data_Id)
        except Exception:
            print("INPUT INVALIDO : Id de Genoma inexistente")
            type = -1
        if (type != -1 and type != 2 ):
            levelone.addkey(data_Id,"EMPTY")
            #falta adicionar ao registo total a info e incializar a CDS especifica
            print("Genoma adicionado com SUCESSO")
    else:
        print("Opcao errada!")






def main():
    levelone = LevelOne()
    #registos = Record()
    work=1
    print("Bem-Vindo!")
    while (work):
        print("O que pretende fazer? \n 1 - Operacoes sobre a Database \n 2 - Obter resultados \n X - Sair")
        option = raw_input(">")
        if (str(option) == "1"):
            inputChange(levelone)
        elif (str(option) == "2"):
            options = {0:getFuncFromID,1:getSeqFromID,2 : getAAfromID,3 : getDomainFromID,4 : getIDfromSeq,5 : getTipoFromID,6 : getIDUniProt,7 : getLocusTag,8 : getGeneName, 9 : getProteinID}
            #imprimir lista das funcionalidades
            print ("Funcionalidade pretendida")
            num =int(raw_input())
            print("Insira o Id")
            id = raw_input()
            options[num](id)
            print("OLA")
        elif(str(option) == "X" or str(option) == "x" ):
            print("Ate uma proxima")
            break
        else:
            print("Input Error - Selecione novamente uma opcao")
        
        

if __name__ == "__main__":
    main()