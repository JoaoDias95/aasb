from collections import defaultdict

class LevelTwo:
    
    def __init__(self):
        self.data = defaultdict(list)
        
    def addkey(self, cds, protein):
    	self.data[cds].append(protein)