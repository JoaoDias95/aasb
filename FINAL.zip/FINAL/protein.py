class Protein:
    
    def __init__(self,name,ecs,seq):
        self.prot_name=name
        self.ecs=ecs
        self.aa=aa
