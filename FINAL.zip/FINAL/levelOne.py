from collections import defaultdict
from Bio import Entrez
from Bio import SeqIO

class LevelOne:

    def __init__(self):
        self.data = defaultdict(list)
        
    def addkey(self, genome, cds):
    	self.data[genome].append(cds)

    def presentGeneTb (self):
        vals = self.data.keys()
        for y in range(0, len(vals)):
            line = ""
            line += str(y) 
            line += ' -> '
            line += str(vals[y])
            print (line)
    
    def getKeys(self):
        return self.data.keys()
    
    def getValues(self, id):
        return self.data[id]

    def isGene(self,id):
        Entrez.email = "a71369@alunos.uminho.pt"
        #ncbi access
        handle = Entrez.efetch(db="nucleotide", rettype="gb", retmode="gbwithparts", id=id)
        seq_record = SeqIO.read(handle, "gb")
        SeqIO.write(seq_record,"aux.gb", "genbank")
        #adicionar values que nos intressam ao registo
        handle.close()